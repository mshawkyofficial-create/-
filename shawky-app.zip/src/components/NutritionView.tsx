import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LockedFeature } from './LockedFeature';
import {
  Utensils,
  Plus,
  Flame,
  PieChart,
  Check,
  ArrowRight,
  ArrowLeft,
  BookOpen,
  Sparkles,
  Video,
  Layers,
  ShieldCheck,
} from 'lucide-react';

export const NutritionView: React.FC = () => {
  const {
    user,
    nutritionPlans,
    consumedNutrition,
    logNutritionQuickAdd,
    selectClientMealOption,
    setActiveTab,
    language,
    setShowAuthModal,
    setAuthMode,
    t,
  } = useApp();

  const isRtl = language === 'ar';
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  const activeAssignedPlan =
    nutritionPlans.find((p) => p.clientId === user.id) || nutritionPlans[0];

  const hasNutrition = user.entitlements.hasNutrition;

  // Quick Add Food dialog
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [addMealName, setAddMealName] = useState('');
  const [addCalories, setAddCalories] = useState(350);
  const [addProtein, setAddProtein] = useState(30);
  const [addCarbs, setAddCarbs] = useState(40);
  const [addFat, setAddFat] = useState(10);

  if (!hasNutrition) {
    return (
      <div className="pt-20 pb-28">
        <LockedFeature
          productName={t('nutritionProduct')}
          productType="nutrition"
          onOpenRedeem={() => {
            setAuthMode('activate');
            setShowAuthModal(true);
          }}
        />
      </div>
    );
  }

  // Use coach assigned target calories & macros
  const totalCaloriesTarget = activeAssignedPlan?.dailyCalories || user.dailyCaloriesTarget || 2200;
  const proteinTarget = activeAssignedPlan?.proteinGrams || user.proteinTarget || 160;
  const carbsTarget = activeAssignedPlan?.carbsGrams || user.carbsTarget || 250;
  const fatTarget = activeAssignedPlan?.fatGrams || user.fatTarget || 70;

  const currentCalories = consumedNutrition.calories;
  const remainingCalories = Math.max(0, totalCaloriesTarget - currentCalories);
  const caloriePercent = Math.min(100, Math.round((currentCalories / totalCaloriesTarget) * 100));

  const proteinPercent = Math.min(100, Math.round((consumedNutrition.protein / proteinTarget) * 100));
  const carbsPercent = Math.min(100, Math.round((consumedNutrition.carbs / carbsTarget) * 100));
  const fatPercent = Math.min(100, Math.round((consumedNutrition.fat / fatTarget) * 100));

  const handleQuickAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    logNutritionQuickAdd(
      Number(addCalories),
      Number(addProtein),
      Number(addCarbs),
      Number(addFat)
    );
    setShowQuickAdd(false);
    setAddMealName('');
  };

  return (
    <div className="flex flex-col w-full max-w-4xl mx-auto px-4 sm:px-6 pt-20 pb-28 gap-6 animate-fade-in text-start">
      {/* Top Banner */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#191c1e]">
            {t('nutritionTracking')}
          </h1>
          <p className="text-xs sm:text-sm text-[#565e74]">
            {isRtl ? 'أهداف التغذية والوجبات المقررة لك من الكوتش' : 'Your Coach-Prescribed Targets & Daily Meals'}
          </p>
        </div>
        <button
          onClick={() => setShowQuickAdd(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-[#ccff00] text-[#191c1e] text-xs font-black shadow-md shadow-[#ccff00]/25 hover:bg-[#b8e600] active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>{t('addFood')}</span>
        </button>
      </div>

      {/* Main Calories & Macros Overview Card (Coach Targets) */}
      <div className="w-full bg-white rounded-3xl p-6 border border-[#e0e3e5] shadow-xs flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          {/* Calorie Stats */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-start">
            <span className="text-xs font-bold text-[#506600] uppercase tracking-wider flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              {isRtl ? 'الهدف اليومي المعتمد من الكوتش' : 'Trainer Prescribed Target'}
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl sm:text-5xl font-black text-[#191c1e] tracking-tight">
                {currentCalories.toLocaleString()}
              </span>
              <span className="text-sm font-bold text-[#565e74]">
                / {totalCaloriesTarget.toLocaleString()} {t('kcal')}
              </span>
            </div>
            <p className="text-xs font-semibold text-[#506600] mt-1">
              {remainingCalories} {t('kcal')} {t('remaining')}
            </p>
          </div>

          {/* Calorie Progress Bar */}
          <div className="w-full sm:w-64 flex flex-col gap-1.5">
            <div className="flex justify-between text-xs font-bold text-[#565e74]">
              <span>{t('completed')}</span>
              <span>{caloriePercent}%</span>
            </div>
            <div className="w-full h-3.5 bg-[#f2f4f6] rounded-full overflow-hidden p-0.5 border border-[#e0e3e5]">
              <div
                className="h-full bg-[#506600] rounded-full transition-all duration-700"
                style={{ width: `${caloriePercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* 3 Macro Cards (Protein, Carbs, Fat) */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-4">
          {/* Protein */}
          <div className="bg-[#f7faf0] rounded-2xl p-3.5 border border-[#506600]/20 flex flex-col">
            <span className="text-[11px] font-extrabold text-[#506600] uppercase">
              {t('protein')}
            </span>
            <span className="text-base sm:text-lg font-black text-[#191c1e] mt-1">
              {consumedNutrition.protein}g
            </span>
            <span className="text-[10px] font-bold text-[#565e74]">
              / {proteinTarget}g
            </span>
            <div className="w-full h-1.5 bg-black/10 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-[#506600] rounded-full"
                style={{ width: `${proteinPercent}%` }}
              />
            </div>
          </div>

          {/* Carbs */}
          <div className="bg-[#f0f9ff] rounded-2xl p-3.5 border border-[#38bdf8]/30 flex flex-col">
            <span className="text-[11px] font-extrabold text-[#0284c7] uppercase">
              {t('carbs')}
            </span>
            <span className="text-base sm:text-lg font-black text-[#191c1e] mt-1">
              {consumedNutrition.carbs}g
            </span>
            <span className="text-[10px] font-bold text-[#565e74]">
              / {carbsTarget}g
            </span>
            <div className="w-full h-1.5 bg-black/10 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-[#0284c7] rounded-full"
                style={{ width: `${carbsPercent}%` }}
              />
            </div>
          </div>

          {/* Fat */}
          <div className="bg-[#fffbeb] rounded-2xl p-3.5 border border-[#fbbf24]/30 flex flex-col">
            <span className="text-[11px] font-extrabold text-[#d97706] uppercase">
              {t('fat')}
            </span>
            <span className="text-base sm:text-lg font-black text-[#191c1e] mt-1">
              {consumedNutrition.fat}g
            </span>
            <span className="text-[10px] font-bold text-[#565e74]">
              / {fatTarget}g
            </span>
            <div className="w-full h-1.5 bg-black/10 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-[#d97706] rounded-full"
                style={{ width: `${fatPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Find Recipes for My Macros Action Button */}
        <button
          onClick={() => setActiveTab('recipes')}
          className="w-full h-12 rounded-2xl bg-[#f2f4f6] hover:bg-[#e6e8ea] active:scale-[0.98] text-[#191c1e] font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all border border-[#e0e3e5]"
        >
          <BookOpen className="w-4 h-4 text-[#506600]" />
          <span>{t('findRecipesForMacros')}</span>
          <ArrowIcon className="w-4 h-4" />
        </button>
      </div>

      {/* COACH ASSIGNED MEAL SCHEDULE / خطة الوجبات المقررة من الكوتش */}
      {activeAssignedPlan && (
        <div className="w-full bg-white rounded-3xl p-6 border border-[#e0e3e5] shadow-xs flex flex-col gap-4 text-start">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#ccff00]/30 text-[#506600] flex items-center justify-center">
                <Utensils className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-black text-[#191c1e]">
                  {isRtl ? 'البرنامج الغذائي المخصص' : 'Coach-Prescribed Meal Plan'}
                </h3>
                <p className="text-xs text-[#565e74]">
                  {totalCaloriesTarget} kcal/day • P: {proteinTarget}g • C: {carbsTarget}g • F: {fatTarget}g
                </p>
              </div>
            </div>
            <span className="text-[10px] font-black text-[#506600] bg-[#f7faf0] px-2.5 py-1 rounded-full border border-[#506600]/20 uppercase">
              {isRtl ? 'الخطة النشطة' : 'Active Plan'}
            </span>
          </div>

          {/* Trainer Notes */}
          {activeAssignedPlan.notes && (
            <div className="bg-[#f7faf0] p-3.5 rounded-2xl border border-[#506600]/20 text-xs text-[#191c1e]">
              <span className="font-black text-[#506600] block mb-0.5">
                {isRtl ? '📌 إرشادات الكوتش:' : '📌 Trainer Guidelines:'}
              </span>
              <p className="text-[#565e74] leading-relaxed">{activeAssignedPlan.notes}</p>
            </div>
          )}

          <div className="flex flex-col gap-4">
            {activeAssignedPlan.meals.map((m, idx) => {
              const hasOptions = m.options && m.options.length > 0;
              const activeOptIdx = m.selectedOptionIndex || 0;
              const activeOption = hasOptions ? m.options[activeOptIdx] || m.options[0] : null;
              const currentFoods = activeOption ? activeOption.foods : m.foods;
              const currentCalories = activeOption ? activeOption.calories : m.calories;
              const currentProtein = activeOption ? activeOption.protein : m.protein;
              const currentCarbs = activeOption ? activeOption.carbs : m.carbs;
              const currentFat = activeOption ? activeOption.fat : m.fat;
              const currentNotes = activeOption?.notes || m.notes;
              const currentSubs = activeOption?.substitutions || m.substitutions;

              return (
                <div
                  key={m.id || idx}
                  className="p-5 rounded-2xl bg-[#f7f9fb] border border-[#e0e3e5] flex flex-col gap-3.5 hover:border-[#506600]/40 transition-all"
                >
                  {/* Meal Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-[#191c1e]">
                        {typeof m.name === 'string'
                          ? m.name
                          : isRtl
                          ? m.name?.ar || m.name?.en || `الوجبة ${idx + 1}`
                          : m.name?.en || m.name?.ar || `Meal ${idx + 1}`}
                      </span>
                      {m.timing && (
                        <span className="text-[10px] text-[#565e74] bg-white px-2.5 py-0.5 rounded-full border border-[#e0e3e5] font-semibold">
                          {m.timing}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {hasOptions && (
                        <span className="text-[10px] font-bold text-[#506600] bg-[#ccff00]/25 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Layers className="w-3 h-3" />
                          {isRtl ? '٣ خيارات متاحة' : `${m.options.length} Options Available`}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* 3 Options Selector Pills */}
                  {hasOptions && (
                    <div className="grid grid-cols-3 gap-2 bg-white/70 p-1.5 rounded-xl border border-[#e0e3e5]">
                      {m.options.map((opt, optIdx) => {
                        const isSelected = optIdx === activeOptIdx;
                        return (
                          <button
                            key={opt.id || optIdx}
                            type="button"
                            onClick={() => selectClientMealOption(activeAssignedPlan.id, m.id, optIdx)}
                            className={`px-2.5 py-2 rounded-lg text-xs font-bold transition-all text-center flex flex-col items-center gap-0.5 ${
                              isSelected
                                ? 'bg-[#191c1e] text-[#ccff00] shadow-sm scale-[1.01]'
                                : 'bg-[#f2f4f6] text-[#565e74] hover:bg-[#e6e8ea]'
                            }`}
                          >
                            <span className="font-extrabold text-[11px] truncate max-w-full">
                              {isRtl ? `الخيار ${optIdx + 1}` : `Option ${optIdx + 1}`}
                            </span>
                            <span className="text-[10px] opacity-85">
                              {opt.calories} kcal
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {/* Active Option Title & Recipe link */}
                  {activeOption && (
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-[#e0e3e5]/60">
                      <span className="text-xs font-extrabold text-[#191c1e]">
                        {typeof activeOption.name === 'string'
                          ? activeOption.name
                          : isRtl
                          ? activeOption.name?.ar || activeOption.name?.en || 'خيار الوجبة'
                          : activeOption.name?.en || activeOption.name?.ar || 'Meal Option'}
                      </span>
                      {activeOption.videoUrl && (
                        <a
                          href={activeOption.videoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-red-600 hover:text-red-700 bg-red-50 px-2 py-0.5 rounded-md border border-red-200"
                        >
                          <Video className="w-3 h-3" />
                          <span>{isRtl ? 'شاهد الفيديو' : 'Video Tutorial'}</span>
                        </a>
                      )}
                    </div>
                  )}

                  {/* Food items with gram weights */}
                  <div className="flex flex-wrap gap-1.5">
                    {(currentFoods || []).map((f, fIdx) => (
                      <span
                        key={f.id || fIdx}
                        className="px-2.5 py-1 rounded-lg bg-white border border-[#e0e3e5] text-[11px] font-bold text-[#191c1e] shadow-2xs"
                      >
                        {typeof f.foodName === 'string'
                          ? f.foodName
                          : isRtl
                          ? f.foodName?.ar || f.foodName?.en || 'طعام'
                          : f.foodName?.en || f.foodName?.ar || 'Food'}{' '}
                        <span className="text-[#506600]">({f.amountGrams}g)</span>
                      </span>
                    ))}
                  </div>

                  {/* Notes & Substitutions */}
                  {currentNotes && (
                    <p className="text-[11px] text-[#565e74] italic">
                      💡 {typeof currentNotes === 'string'
                        ? currentNotes
                        : isRtl
                        ? (currentNotes as any)?.ar || (currentNotes as any)?.en || ''
                        : (currentNotes as any)?.en || (currentNotes as any)?.ar || ''}
                    </p>
                  )}
                  {currentSubs && (
                    <p className="text-[10px] text-[#767e94]">
                      🔄 <span className="font-semibold">{isRtl ? 'البدائل المتاحة:' : 'Substitutions:'}</span>{' '}
                      {typeof currentSubs === 'string'
                        ? currentSubs
                        : isRtl
                        ? (currentSubs as any)?.ar || (currentSubs as any)?.en || ''
                        : (currentSubs as any)?.en || (currentSubs as any)?.ar || ''}
                    </p>
                  )}

                  {/* Macros & Log Action Footer */}
                  <div className="flex items-center gap-3 w-full justify-between border-t pt-3 border-[#e0e3e5]">
                    <div className="text-start">
                      <span className="text-sm font-black text-[#191c1e] block">
                        {currentCalories} kcal
                      </span>
                      <span className="text-[10px] font-bold text-[#565e74] block">
                        P: {currentProtein}g | C: {currentCarbs}g | F: {currentFat}g
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        logNutritionQuickAdd(currentCalories, currentProtein, currentCarbs, currentFat);
                      }}
                      className="px-4 py-2 rounded-xl bg-[#ccff00] hover:bg-[#b8e600] text-[#191c1e] text-xs font-black flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isRtl ? 'تسجيل هذا الخيار' : 'Log Option'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Quick Add Food Modal */}
      {showQuickAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-[#eceef0] flex flex-col gap-4 text-start">
            <h4 className="text-lg font-black text-[#191c1e]">
              {t('addFood')}
            </h4>
            <form onSubmit={handleQuickAddSubmit} className="flex flex-col gap-3">
              <div>
                <label className="text-xs font-bold text-[#565e74] uppercase block mb-1">
                  {isRtl ? 'اسم الوجبة / الصنف' : 'Food / Meal Name'}
                </label>
                <input
                  type="text"
                  value={addMealName}
                  onChange={(e) => setAddMealName(e.target.value)}
                  placeholder="e.g. Greek Yogurt & Honey"
                  className="w-full h-10 px-3 rounded-xl bg-[#f2f4f6] text-xs font-medium text-[#191c1e] outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#565e74] uppercase block mb-1">
                  {t('calories')} (kcal)
                </label>
                <input
                  type="number"
                  value={addCalories}
                  onChange={(e) => setAddCalories(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-xl bg-[#f2f4f6] text-xs font-bold text-[#191c1e] outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-[#506600] uppercase block mb-1">
                    {t('protein')} (g)
                  </label>
                  <input
                    type="number"
                    value={addProtein}
                    onChange={(e) => setAddProtein(Number(e.target.value))}
                    className="w-full h-9 px-2 rounded-lg bg-[#f2f4f6] text-xs font-bold text-center outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[#0284c7] uppercase block mb-1">
                    {t('carbs')} (g)
                  </label>
                  <input
                    type="number"
                    value={addCarbs}
                    onChange={(e) => setAddCarbs(Number(e.target.value))}
                    className="w-full h-9 px-2 rounded-lg bg-[#f2f4f6] text-xs font-bold text-center outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-[#d97706] uppercase block mb-1">
                    {t('fat')} (g)
                  </label>
                  <input
                    type="number"
                    value={addFat}
                    onChange={(e) => setAddFat(Number(e.target.value))}
                    className="w-full h-9 px-2 rounded-lg bg-[#f2f4f6] text-xs font-bold text-center outline-none"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 h-11 rounded-xl bg-[#ccff00] text-[#191c1e] font-black text-xs"
                >
                  {isRtl ? 'تسجيل في خطة اليوم' : 'Log Food'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowQuickAdd(false)}
                  className="px-4 h-11 rounded-xl bg-[#f2f4f6] text-[#565e74] font-bold text-xs"
                >
                  {isRtl ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
